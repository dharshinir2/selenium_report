import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Calc {
  
	 @Test(dataProvider="dp")
	  public void add(int num1,int num2,int expected) {
		  int actual=num1+num2;
		  Assert.assertEquals(expected,actual);
	  }
	 @Test(dataProvider="ds")
	  public void sub(int num1,int num2,int expected) {
		  int actual=num1-num2;
		  Assert.assertEquals(expected,actual);
	  }
	 @Test(dataProvider="dm")
	  public void mul(int num1,int num2,int expected) {
		  int actual=num1*num2;
		  Assert.assertEquals(expected,actual);
	  }
	 @Test(dataProvider="dd")
	  public void div(int num1,int num2,int expected) {
		  int actual=num1/num2;
		  Assert.assertEquals(expected,actual);
	  }
	  @DataProvider
	  public Object [][] dp(){
		  return new Object[][] {
			  new Object[] {1,2,3},
			  new Object[] {2,3,5},
		  };
}
	  @DataProvider
	  public Object [][] ds(){
		  return new Object[][] {
			  new Object[] {5,2,3},
			  new Object[] {8,3,5},
		  };
}
	  @DataProvider
	  public Object [][] dm(){
		  return new Object[][] {
			  new Object[] {5,2,10},
			  new Object[] {8,3,24},
		  };
}
	  @DataProvider
	  public Object [][] dd(){
		  return new Object[][] {
			  new Object[] {5,5,1},
			  new Object[] {8,2,4},
		  };
}
}
