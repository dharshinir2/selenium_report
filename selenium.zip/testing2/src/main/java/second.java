import org.testng.Assert;
import org.testng.annotations.Test;

public class second {
	int a=20;
	int b=10;
  @Test
  public void addition() {
	  int c=a+b;
	  Assert.assertEquals(c, 30);
  
  }
  @Test
  public void subtraction() {
	  int c=a-b;
	  Assert.assertEquals(c, 10);
	  
  }
  @Test
  public void multiplication() {
	  int c=a*b;
	  Assert.assertEquals(c, 200);
	  
  }
  @Test
  public void division() {
	  int c=a/b;
	  Assert.assertEquals(c, 2);
	  
  }
}
