import org.testng.annotations.Test;

public class d9_05 {
  @Test
  public void f() {
  }
}
